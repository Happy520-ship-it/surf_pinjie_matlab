function varargout = harri_ransac(varargin)
% HARRI_RANSAC M-file for harri_ransac.fig
%      HARRI_RANSAC, by itself, creates a new HARRI_RANSAC or raises the existing
%      singleton*.
%
%      H = HARRI_RANSAC returns the handle to a new HARRI_RANSAC or the handle to
%      the existing singleton*.
%
%      HARRI_RANSAC('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in HARRI_RANSAC.M with the given input arguments.
%
%      HARRI_RANSAC('Property','Value',...) creates a new HARRI_RANSAC or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before harri_ransac_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to harri_ransac_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)". 
%

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @harri_ransac_OpeningFcn, ...
                   'gui_OutputFcn',  @harri_ransac_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before harri_ransac is made visible.
function harri_ransac_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to harri_ransac (see VARARGIN)

% Choose default command line output for harri_ransac
handles.output = hObject;
%�ڳ���Openning_Fcn���������´���

handles.output = hObject;
ha=axes('units','normalized','pos',[0 0 1 1]);
 uistack(ha,'down');
 ii=imread('�羰.jpg'); %ͼƬ�Լ���
 image(ii);
 colormap gray
 set(ha,'handlevisibility','off','visible','off');
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes harri_ransac wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = harri_ransac_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
[name,path]=uigetfile({'*.jpg';'*.bmp';'gif'},'����ͼ��');
	if isequal(name,0)|isequal(path,0)
	    errordlg('���ˣ�û��ѡ���ļ���','����');
	    return;
	else
	    img1=imread([path,name]);  %��ȡλ��
	    axes(handles.axes1);%axes��ʾ��ȡλ�ã�����ѡȡ��λ��Ϊaxes1��
        %x=imresize(x,[800 870]);  %�趨ͳһ�ߴ�
	    imshow(img1); %��ʾͼ��
        title('ͼ��һ');
        save('img1');  %�������
	   guidata(hObject,handles) %���½ṹ�壻
    end
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
[name,path]=uigetfile({'*.jpg';'*.bmp';'gif'},'����ͼ��');
	if isequal(name,0)|isequal(path,0)
	    errordlg('���ˣ�û��ѡ���ļ���','����');
	    return;
	else
	    img2=imread([path,name]);  %��ȡλ��
	    axes(handles.axes2);%axes��ʾ��ȡλ�ã�����ѡȡ��λ��Ϊaxes1��
       % x=imresize(x,[800 870]);  %�趨ͳһ�ߴ�
	    imshow(img2); %��ʾͼ��
        title('ͼ���');
        save('img2');  %�������
	   guidata(hObject,handles) %���½ṹ�壻
    end
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
msgbox('����harris��������ƴ�ӣ�����ʱ��������δ����ʣ�²��֣�QQ1321814823���ÿ�������ͳ���')
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)




% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
clc
close all
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
